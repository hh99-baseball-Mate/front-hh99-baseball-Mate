import React from "react";
import styled from "styled-components";

const MarginBottom = () => {
	return (
		<Box>

		</Box>
	)
}

export default MarginBottom;

const Box = styled.div`
	width: 0;
	height: 0;
	margin-bottom: 94px;
`;